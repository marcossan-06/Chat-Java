//Importamos librerías de I/O y redes.
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ChatCliente {
    public static void main(String[] args) {
        /*
        Creamos un socket para nuestra conexión con el servidor.
        IMPORTANTE, EL PUERTO DEBE COINCIDIR CON EL DEL SERVER
        */
        try (Socket socket = new Socket("localhost", 51000)) {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8)); // Entrada de datos del server
            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true); // Salida de datos hacia el server

            // Entrada de datos del teclado, como Scanner, pero más eficiente y solo Strings
            BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));

            // Pedimos el nombre al usuario
            System.out.println("Introduce tu nombre: ");
            String nombreUsuario = teclado.readLine();

            out.println(nombreUsuario); //Enviamos el nombre al server

            /* Creamos y ejecutamos el siguiente hilo
            que se encarga de RECIBIR los mensajes del server */
            new Thread(() -> {
                try {
                    String mensaje;
                    /*
                     Leemos mensajes que llegan del server sin parar
                     hasta que se desconecte.
                    */
                    while ((mensaje = in.readLine()) != null) {
                        if (mensaje.startsWith("\uD83D\uDCAC [" + nombreUsuario + "]")) {
                            // Es un mensaje enviado por este cliente ya, que coincide el nombre de usuario.
                            System.out.println("\uD83D\uDCE4 T\u00FA: " + mensaje.substring(mensaje.indexOf("]") + 2));
                        }
                        else {
                            // Es un mensaje recibido de otro usuario
                            System.out.println("\uD83D\uDCE9 " + mensaje);
                        }
                                            }
                } catch (IOException e) {
                    System.out.println("Te has desconectado del servidor.");
                }
            }).start();

            // En la ejecución principal ENVIAREMOS los mensajes al server
            String mensaje;
            while ((mensaje = teclado.readLine()) != null) {
                out.println(mensaje); // Enviamos el mensaje
            }

        } catch (IOException e) {
            e.printStackTrace(); //Capturamos y mostramos los errores
        }
    }
}
