//Importamos librerías de I/O, redes y colecciones.
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;

public class ChatServidor {
    /*
    Declaro e inicializo una constante para el número de puerto y
    una colección de ELEMENTOS ÚNICOS para guardar a los clientes conectados.
    IMPORTANTE USAR UN PUERTO NO USADO HABITUALMENTE (+50000)
    */
    private static final int PUERTO = 51000;
    private static HashSet<PrintWriter> clientes = new HashSet<>();

    public static void main(String[] args) {
        System.out.println("El servidor se ha iniciado...");

        /*
        Creo el socket en el puerto indicado, como recurso del try
        de esta manera se cerrará automáticamente al finalizar el bloque try,
        así omitiremos tener que cerrarlo en el finally.
        Esto es gracias a que la clase ServerSocket implementa la
        interfaz Closeable.
         */
        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            // Bucle infinito para que el server acepte clientes continuamente.
            while (true) {
                /* Usamos el método accept() para crear el socket cuando un
                 cliente se conecta
                 */
                Socket socket = serverSocket.accept();
                /* PrintWriter para enviar mensajes al cliente.
                   AutoFlush activado para que se vacíe el buffer y
                   enviar los datos inmediatamente sin tener que hacer el flush() manual.
                   (UTF-8 para visualizar los emoticonos en la terminal)
                 */
                PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
                // Añadimos el cliente al HashSet.
                clientes.add(out);
                // Crea y ejecuta un hilo mediante la clase ManejadorCliente.
                new ManejadorCliente(socket, out).start();
            }
        } catch (IOException ex) {
            // Comunicamos que ha habido un problema
            System.out.println("Error al iniciar el servidor:");
            ex.printStackTrace();
        }
    }

    /*
    Método privado que usa el server para enviar un mensaje a todos
    los clientes conectados
    */
    private static void enviarMensajeATodos(String mensaje) {
        for (PrintWriter cliente : clientes) {
            cliente.println(mensaje);
        }
    }

    /*
    Clase interna y privada del server con la
    que manejaremos cada hilo de ejecución de cada cliente.
    */
    private static class ManejadorCliente extends Thread {
        //Atributos
        private Socket socket; // Socket del cliente.
        private PrintWriter out; // Salida de datos del cliente.
        private BufferedReader in; // Entrada de datos del cliente.
        private String nombreUsuario; //Nombre de usuario del cliente.

        //Constructor
        public ManejadorCliente(Socket socket, PrintWriter out) {
            this.socket = socket;
            this.out = out;
        }

        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                nombreUsuario = in.readLine();
                System.out.println(nombreUsuario + " se ha conectado.");
                enviarMensajeATodos("\uD83D\uDCE2 " + nombreUsuario + " se ha unido al chat.");

                /*
                 Leemos mensajes constantemente hasta que el cliente se desconecta (null).
                 Y los envíamos a cada cliente conectado.
                 */
                String mensaje;
                while ((mensaje = in.readLine()) != null) {
                    enviarMensajeATodos("\uD83D\uDCAC [" + nombreUsuario + "] " + mensaje);
                }

            /* Capturamos los fallos de red y I/0, de manera que por ejemplo
            al desconectarse un cliente el programa no casque.
            */
            } catch (IOException e) {
                System.out.println(nombreUsuario + " se ha desconectado.");
            } finally {
                try {
                    // Cerramos la conexión con el cliente para liberar espacio en memoria.
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                // Eliminamos el cliente del HashSet e informamos a los demás clientes.
                clientes.remove(out);
                enviarMensajeATodos("\uD83D\uDCE2 " + nombreUsuario + " ha salido del chat.");
                System.out.println(nombreUsuario + " se ha desconectado.");
            }
        }
    }
}
